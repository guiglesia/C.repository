

struct cliente
	{
    char nome[100];
    char nome_armazenado[100];
    char cpf [18];
    char cpf_armazenado[18];
    int codigo;
    int codigo_armazenado;
};



