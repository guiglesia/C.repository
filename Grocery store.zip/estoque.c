#include "estoque.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>
	
int a = 1;
int existe, codigo;
int x, z, t;





void estoque1(struct food *f, int *p, FILE *warquivo1)
{
	
	existe = 0;
		
		printf("Digite o c�digo da comida:");
		scanf("%d", &codigo);
		for (z = 0; z < *p && !existe; z++)
		
			if (f[z].codigo == codigo) 
			{
				printf("\nC�digo de mercadoria j� cadastrado.\n");
				existe = 1;
			}
		if(!existe)
		{
		f[*p].codigo = codigo;
		fprintf(warquivo1,"\n%d", f[*p].codigo);
		printf("Nome da comida: ");
		scanf("%s", f[*p].comida);
		fprintf(warquivo1,"%s",f[*p].comida);
		printf("Quantidade:");
		scanf("%d", &f[*p].quantidade);
		fprintf(warquivo1," %d",f[*p].quantidade);
		(*p)++;
		}
		
		printf("*************************Estoque Atualizado*************************\n");
	
	
}

void estoque2(struct liquidos *d, int *p2, FILE *warquivo2)
{
	existe = 0;
		
		printf("Digite o c�digo da Bebida:");
		scanf("%d", &codigo);
		for (z = 0; z < *p2 && !existe; z++)
		
			if (d[z].codigo == codigo) 
			{
				printf("\nC�digo de mercadoria j� cadastrado.\n");
				existe = 1;
			}
		if(!existe)
		{
		d[*p2].codigo = codigo;
		fprintf(warquivo2,"\n%d ", d[*p2].codigo);
		printf("Nome da Bebida: ");
		scanf("%s", d[*p2].bebida);
		fprintf(warquivo2,"%s ",d[*p2].bebida);
		printf("Quantidade:");
		scanf(" %d", &d[*p2].quantidade);
		fprintf(warquivo2,"%d",d[*p2].quantidade);
		(*p2)++;
		}
	
		
		printf("*************************Estoque Atualizado*************************\n");
	
}

void estoque3(struct higi *s, int *p3, FILE *warquivo3)
{

		existe = 0;
		
		printf("Digite o c�digo do Produto:");
		scanf("%d", &codigo);
		for (z = 0; z < *p3 && !existe; z++)
			if (s[z].codigo == codigo) 
			{
				printf("\nC�digo de mercadoria j� cadastrado.\n");
				existe = 1;
			}
		if(!existe)
		{
		s[*p3].codigo = codigo;
		fprintf(warquivo3,"\n%d ", s[*p3].codigo);
		printf("Nome do Produto de Higiene: ");
		scanf("%s", s[*p3].higiene);
		fprintf(warquivo3,"%s ",s[*p3].higiene);
		printf("Quantidade:");
		scanf(" %d", &s[*p3].quantidade);
		fprintf(warquivo3,"%d",s[*p3].quantidade);
		(*p3)++;
		}
		
		
		printf("*************************Estoque Atualizado*************************\n");	
}

void estoque4(struct limp *c, int *p4, FILE *warquivo4)
{
	
	existe = 0;
		
		printf("Digite o c�digo do Produto:");
		scanf("%d", &codigo);
		for (z = 0; z < *p4 && !existe; z++)
			if (c[z].codigo == codigo) 
			{
				printf("\nC�digo de mercadoria j� cadastrado.\n");
				existe = 1;
			}

		if(!existe)
		{
		c[*p4].codigo = codigo;
		fprintf(warquivo4,"\n%d ", c[*p4].codigo);
		printf("Nome do Produto de Limpeza: ");
		scanf("%s", c[*p4].limpeza);
		fprintf(warquivo4,"%s ",c[*p4].limpeza);
		printf("Quantidade:");
		scanf(" %d", &c[*p4].quantidade);
		fprintf(warquivo4,"%d",c[*p4].quantidade);
		(*p4)++;
		}
		
		
		printf("*************************Estoque Atualizado*************************\n");
	
}
	
void estoque5(struct cig *cigar, int *p5, FILE *warquivo5)
{
	
	existe = 0;
		
		printf("Digite o c�digo do Produto:");
		scanf("%d", &codigo);
		for (z = 0; z < *p5 && !existe; z++)
		
			if (cigar[z].codigo == codigo) 
			{
				printf("\nC�digo de mercadoria j� cadastrado.\n");
				existe = 1;
			}
		if(!existe)
		{
		cigar[*p5].codigo = codigo;
		fprintf(warquivo5,"\n%d ", cigar[*p5].codigo);
		printf("Nome do Produto de Limpeza: ");
		scanf("%s", cigar[*p5].cigarro);
		fprintf(warquivo5,"%s ",cigar[*p5].cigarro);
		printf("Quantidade:");
		scanf(" %d", &cigar[*p5].quantidade);
		fprintf(warquivo5,"%d", cigar[*p5].quantidade);
		(*p5)++;
		}
		
		
		printf("*************************Estoque Atualizado*************************\n");	
}	

	//---------------------------------------------Checagem----------------------------------------------------//
void estoquecheck1(struct food *f, int p, FILE *rarquivo1)
{
	int i;
	
	printf("\n-------------------------ESTOQUE DE COMIDAS-------------------------\n");
	if(p == 0)
	{
		printf("N�o existem comidas cadastradas recentemente.\n");
	}
	else
	{
		printf("\nComidas armazenadas recentemente:\n");
		for(i = 0; i < p; i++)
		{
			printf("- ID:%d\tQtd:%d\tPrd:%s\n", f[i].codigo, f[i].quantidade, f[i].comida);
		}
	}
	
	if(rarquivo1 == 0)
	{
		printf("N�o existem comidas armazenadas no banco de dados\n");
	}
	else
	{
		i = 0;
		printf("\nEstoque geral de Comidas:\n");
		while(!feof(rarquivo1)) 
				{
                    fscanf(rarquivo1, "%d %s %d", &f[i].codigo_armazenado, f[i].comida_armazenada, &f[i].quantidade_armazenada);
                    if(f[i].codigo_armazenado == 0)
                    {
                    	break;
					}
                    printf("- ID:%d\tQtd:%d\tPrd:%s\n", f[i].codigo_armazenado, f[i].quantidade_armazenada, f[i].comida_armazenada);
                    i++;
                }
	}
}


void estoquecheck2(struct liquidos *d, int p2, FILE *rarquivo2)
{
	int i;
	
	printf("-------------------------ESTOQUE DE BEBIDAS-------------------------\n");
	
	if(p2 == 0)
	{
		printf("N�o existem Bebidas cadastradas recentemente.\n");
	}
	else
	{
		printf("\nBebidas armazenadas recentemente:\n");
		for(i = 0; i < p2; i++)
		{
			printf("- ID:%d\t Qtd:%d\t Prd:%s\n", d[i].codigo, d[i].quantidade, d[i].bebida);
		}
	}
	
	if(rarquivo2 == 0)
	{
		printf("N�o existem Bebidas armazenadas no banco de dados\n");
	}
	else
	{
	i = 0;
	printf("\nEstoque geral de Bebidas:\n");
		while(!feof(rarquivo2)) 
				{
                    fscanf(rarquivo2, "%d %s %d", &d[i].codigo_armazenado, d[i].bebida_armazenada, &d[i].quantidade_armazenada);
                    if(d[i].codigo_armazenado == 0)
                    {
                    	break;
					}
                    printf("- ID:%d\t Qtd:%d\t Prd:%s\n", d[i].codigo_armazenado,  d[i].quantidade_armazenada, d[i].bebida_armazenada);
                    i++;
                }
	}
}

void estoquecheck3(struct higi *s, int p3, FILE *rarquivo3)
{
	int i;
	
	printf("-------------------------ESTOQUE DE HIGIENE-------------------------\n");
	if(p3 == 0)
	{
		printf("N�o existem produtos de Higiene cadastrados recentemente.\n");
	}
	else
	{
		printf("\nProdutos de Higiene armazenados recentemente:\n");
		for(i = 0; i < p3; i++)
		{
			printf("- ID:%d\t Qtd:%d\t Prd:%s\n", s[i].codigo, s[i].quantidade, s[i].higiene);
		}
	}
	
	if(rarquivo3 == 0)
	{
		printf("N�o existem Produtos de higiene cadastrados\n");
	}
	else
	{
		printf("\nEstoque geral de Produtos de Higiene:\n");
		while(!feof(rarquivo3)) 
				{
                    fscanf(rarquivo3, "%d %s %d", &s[i].codigo, s[i].higiene, &s[i].quantidade);
                    if(s[i].codigo_armazenado == 0)
                    {
                    	break;
					}
                    printf("ID:%d\t %d\t %s\n", s[i].codigo_armazenado,  s[i].quantidade_armazenada, s[i].higiene_armazenada);
                    i++;
                }
	}
}

void estoquecheck4(struct limp *c, int p4, FILE *rarquivo4)
{
	int i;
	
	printf("-------------------------ESTOQUE DE LIMPEZA-------------------------\n");
	
	if(p4 == 0)
	{
		printf("N�o existem produtos de Limpeza cadastrados recentemente.\n");
	}
	else
	{
		printf("\nProdutos de Limpeza armazenados recentemente:\n");
		for(i = 0; i < p4; i++)
		{
			printf("- ID:%d\t Qtd:%d\t Prd:%s\n", c[i].codigo, c[i].quantidade, c[i].limpeza);
		}
	}
	
	if(rarquivo4 == 0)
	{
		printf("N�o existem produtos de Limpeza cadastrados\n");
	}
	else
	{
		printf("\nEstoque geral de Produtos de Limpeza:\n");
		while(!feof(rarquivo4)) 
				{
                    fscanf(rarquivo4, "%d %s %d", &c[i].codigo_armazenado, c[i].limpeza_armazenada, &c[i].quantidade_armazenada);
                    if(c[i].codigo_armazenado == 0)
                    {
                    	break;
					}
                    printf("ID:%d\t %d\t %s\n", c[i].codigo_armazenado, c[i].quantidade_armazenada ,c[i].limpeza_armazenada);
                    i++;
                }
        
	}
}

void estoquecheck5(struct cig *cigar, int p5, FILE *rarquivo5)
{
	int i;
	
	printf("-------------------------ESTOQUE DE CIGARROS-------------------------\n");
	
	if(p5 == 0)
	{
		printf("N�o existem Cigarros cadastrados recentemente.\n");
	}
	else
	{
		printf("\nCigarros armazenados recentemente:\n");
		for(i = 0; i < p5; i++)
		{
			printf("- ID:%d\t Qtd:%d\t Prd:%s\n", cigar[i].codigo, cigar[i].quantidade, cigar[i].cigarro);
		}
	}
	if(rarquivo5 == 0)
	{
		printf("N�o existem cigarros cadastrados\n");
	}
	else
	{
		printf("\nEstoque geral de Cigarros:\n");
		while(!feof(rarquivo5)) 
		{
					fscanf(rarquivo5, "%d %s %d", &cigar[i].codigo_armazenado, cigar[i].cigarro_armazenado, &cigar[i].quantidade_armazenada);
					if(cigar[i].codigo_armazenado == 0)
					{
						break;
					}
                    printf("ID:%d\t %d\t %s\n", cigar[i].codigo_armazenado, cigar[i].quantidade_armazenada, cigar[i].cigarro_armazenado);
                    i++;
    	}
    	
	}
}



