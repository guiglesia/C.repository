#include <stdio.h>

struct food	
	{
		char comida[100];
		char comida_armazenada[100];
		int quantidade;
		int quantidade_armazenada;
		int codigo;	
		int codigo_armazenado;
	};
	
	
struct liquidos
	{
		char bebida[100];
		char bebida_armazenada[100];
		int quantidade;
		int quantidade_armazenada;
		int codigo;
		int codigo_armazenado;
	};
	
	

struct higi
	{
		char higiene[100];
		char higiene_armazenada[100];
		int quantidade;
		int quantidade_armazenada;
		int codigo;
		int codigo_armazenado;
	};
	
	
	
struct limp
	{
		char limpeza[100];
		char limpeza_armazenada[100];
		int quantidade;
		int quantidade_armazenada;
		int codigo_armazenado;
		int codigo;
	};
	
	

struct cig
	{
		char cigarro[100];
		char cigarro_armazenado[100];
		int quantidade;
		int quantidade_armazenada;
		int codigo_armazenado;
		int codigo;
	};
	
	
	
void estoque1(struct food*, int*, FILE*);
void estoque2(struct liquidos*, int*, FILE*);
void estoque3(struct higi*, int*, FILE*);
void estoque4(struct limp*, int*, FILE*);
void estoque5(struct cig*, int*, FILE*);

void estoquecheck1(struct food*, int, FILE*);
void estoquecheck2(struct liquidos*, int, FILE*);
void estoquecheck3(struct higi*, int, FILE*);
void estoquecheck4(struct limp*, int, FILE*);
void estoquecheck5(struct cig*, int, FILE*);


