
#include "cadastro.h"
#include "estoque.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

#define N 2
#define C 2

int main()
{
//==============================Adicionando acentua��o em caracteres especiais ===============================//
	setlocale(LC_ALL, "portuguese-brazilian");
//======================== Instanciamento de struct e aloca��o dinamica dos produtos ========================//
	struct food *com;
	struct liquidos *drinks;
	struct higi *selfcare;
	struct limp *cleaning;
	struct cig *cigarrete;
	
	com = (struct food *) malloc(N * sizeof(struct food));
	drinks = (struct liquidos *) malloc(N * sizeof(struct liquidos));
	selfcare = (struct higi *) malloc(N * sizeof(struct higi));
	cleaning = (struct limp *) malloc(N * sizeof(struct limp));
	cigarrete = (struct cig *) malloc(N * sizeof(struct cig));

//===================================== Inicia��o de v�riaveis =============================================//
	int g, c;
	char  cc[4];
	int x = 0;
    int t = 0, i;
    int w, j;
    int qtd_memory;
    int qtd_merc1, qtd_merc2, qtd_merc3, qtd_merc4, qtd_merc5;
    qtd_memory = N;
    int *p;
    qtd_merc1 = 0;
    qtd_merc2 = 0;
    qtd_merc3 = 0;
    qtd_merc4 = 0;
    qtd_merc5 = 0;
      
    
//======================== Instaciamento e aloca��o dinamica de cadastro ===================================//
    struct cliente *cadas; 
    cadas = (struct cliente *) malloc(C * sizeof(struct cliente));
    int qtd_cadas;
    
//==========================================================================================================//
	FILE *warquivo1, *rarquivo1;
	FILE *warquivo2, *rarquivo2;
	FILE *warquivo3, *rarquivo3;
	FILE *warquivo4, *rarquivo4;
	FILE *warquivo5, *rarquivo5;
	FILE *warquivocli, *rarquivocli;
//==========================================================================================================//

    
	while(g != 4)
	{	
	printf("\n--------- Bem vindo ao BSI020TECH - O futuro no seu neg�cio ---------\n\n");
	printf("--------------------------MERCEARIA PAULINO--------------------------\n");
	printf("\nSELECIONE A OP��O DESEJADA.\n\n");
	printf("- 1. Sistema de cadastro de clientes\n");
	printf("- 2. Atualiza��o de estoque\n");
	printf("- 3. Checar estoque\n");
	printf("- 4. Sair\n");
	printf("\n-");
	scanf("%d", &g);
	
	if(g == 1)
	{
		
		printf("-------------------------Sistema de cadastro-------------------------\n");
    	printf("\n- 1. Cadastrar cliente");
    	printf("\n- 2. Checar clientes cadastrados\n");
    	printf("\n-");
    	scanf("%d", &c);

        if(c == 1)
        {
        	warquivocli = fopen("cadastro.txt", "a");
			if(!warquivocli)
			{
				warquivocli = fopen("cadastro.txt", "w");
			}
        	
        	printf("\n- Digite o c�digo do cliente:");
            scanf("%d", &cadas[x].codigo);
            fprintf(warquivocli, "\n%d ", cadas[x].codigo);
            printf("\n- Digite o nome do cliente:");
            scanf("%s", cadas[x].nome);
            fprintf(warquivocli, "%s ", cadas[x].nome);
            printf("\n- Digite o CPF do cliente:");
            scanf("%s", &cadas[x].cpf);
            fprintf(warquivocli, "%s", cadas[x].cpf);

            x++;
            printf("\n____________________Cadastro conclu�do com sucesso___________________\n");
            fclose(warquivocli);
        }
        
        else if(c == 2)
        {
        	rarquivocli = fopen("cadastro.txt", "r");
        	
        	if(x == 0)
        	{
        		printf("\n- Nenhum cliente registrado recentemente.\n");
			}
			else
			{
				printf("-Clientes registrados recentemente:\n");
        		for(i = 0; i < x; i++)
        		{
        			printf("\n- Nome:%s\n", cadas[i].nome);
        			printf("\n- CPF:%s\n", cadas[i].cpf);
        			printf("_________________________________");
				}
			}
			
				if(rarquivocli != NULL)
				{
					i = 0;
					
					printf("\n- Banco de dados do sistema:\n");
					while(!feof(rarquivocli)) 
					{
                    	fscanf(rarquivocli, "%d %s %s", &cadas[i].codigo_armazenado, cadas[i].nome_armazenado, cadas[i].cpf_armazenado);
                    	if(cadas[i].codigo_armazenado == 0)
                    	{
                    		printf("\n- Nenhum cliente armazenado no banco de dados.\n");
						}
						else
						{
                    	printf("- ID:%d\t %s\t %s\n", cadas[i].codigo_armazenado, cadas[i].nome_armazenado, cadas[i].cpf_armazenado);
                    	i++;
                		}
				}
				}
				if(rarquivocli == NULL)
				{
					printf("\n- Nenhum cliente armazenado no sistema\n");
				}
			fclose(rarquivocli);
        
		}
		
		else
		{
			printf("\n---- Entrada inv�lida, responda com s OU n ---- (minusculo)*\n\n");
		}
	}
	else if(g == 2)
	{
		int l;
		
		printf("-------------- RETIRE OU ADICIONE MERCADORIAS DO ESTOQUE ------------\n\n");
		printf("-------------------------Selecione o setor---------------------------\n\n");
		printf("- 1.Comida\n- 2.Bebida\n- 3.Higiene\n- 4.Limpeza\n- 5.Cigarro\n\n-");
	
		scanf("%d", &l);
		printf("\n");
		
		if(l == 1)
		{
			if (qtd_merc1 == qtd_memory)
			{
				qtd_memory = qtd_memory + N;
				com = (struct food *) realloc(com, qtd_memory * sizeof(struct food));
			}
			rarquivo1 = fopen("comida.txt", "r");
			warquivo1 = fopen("comida.txt", "a");
			if(!warquivo1)
			{
				warquivo1 = fopen("comida.txt", "w");
			}
			estoque1(com, &qtd_merc1, warquivo1);
			fclose(warquivo1);
		}
		
		if(l == 2)
		{
			if (qtd_merc2 == qtd_memory)
			{
				qtd_memory = qtd_memory + N;
				drinks = (struct liquidos *) realloc(drinks, qtd_memory * sizeof(struct liquidos));
			}
			
			warquivo2 = fopen("bebida.txt", "a");
			if(!warquivo2)
			{
				warquivo2 = fopen("bebida.txt", "w");
			}
			estoque2(drinks, &qtd_merc2, warquivo2);
			fclose(warquivo2);
			
		}
		
		if(l == 3)
		{
			if (qtd_merc3 == qtd_memory)
			{
				qtd_memory = qtd_memory + N;
				selfcare = (struct higi *) realloc(selfcare, qtd_memory * sizeof(struct higi));
			}
			
			warquivo3 = fopen("higiene.txt", "a");
			if(!warquivo3)
			{
				warquivo3 = fopen("higiene.txt", "w");
			}
			estoque3(selfcare, &qtd_merc3, warquivo3);
			fclose(warquivo3);
		}
		
		if(l == 4)
		{
			if (qtd_merc4 == qtd_memory)
			{
				qtd_memory = qtd_memory + N;
				cleaning = (struct limp *) realloc(cleaning, qtd_memory * sizeof(struct limp));
			}
			
			warquivo4 = fopen("limpeza.txt", "a");
			if(!warquivo1)
			{
				warquivo1 = fopen("limpeza.txt", "w");
			}
			estoque4(cleaning, &qtd_merc4, warquivo4);
			fclose(warquivo4);
		}
		
		if(l == 5)
		{
				if (qtd_merc5 == qtd_memory)
			{
				qtd_memory = qtd_memory + N;
				cigarrete = (struct cig *) realloc(cigarrete, qtd_memory * sizeof(struct cig));
			}
			
			warquivo5 = fopen("cigarro.txt", "a");
			if(!warquivo1)
			{
				warquivo1 = fopen("cigarro.txt", "w");
			}
			estoque5(cigarrete, &qtd_merc5, warquivo5);
			fclose(warquivo5);
		}
	}
	else if(g == 3)
	{
		printf("------------------------- CHECAGEM DE ESTOQUE -------------------------\n");
		printf("\nSELECIONE A OP��O DESEJADA\n");
		printf("- 1.Comida\n- 2.Bebida\n- 3.Higiene\n- 4.Limpeza\n- 5.Cigarro\n\n-");
		scanf("%d", &w);
		
		if(w == 1)
		{
			rarquivo1 = fopen("comida.txt", "r");
			estoquecheck1(com, qtd_merc1, rarquivo1);
			fclose(rarquivo1);
		}
	
		if(w == 2)
		{
			rarquivo2 = fopen("bebida.txt", "r");
			estoquecheck2(drinks, qtd_merc2, rarquivo2);
			fclose(rarquivo2);
		}
	
		if(w == 3)
		{
			rarquivo3 = fopen("higiene.txt", "r");
			estoquecheck3(selfcare, qtd_merc3, rarquivo3);
			fclose(rarquivo3);
		}
	
		if(w == 4)
		{
			rarquivo4 = fopen("limpeza.txt", "r");
			estoquecheck4(cleaning, qtd_merc4, rarquivo4);
			fclose(rarquivo4);
		}
	
		if(w == 5)
		{
			rarquivo5 = fopen("cigarro.txt", "r");
			estoquecheck5(cigarrete, qtd_merc5, rarquivo5);
			fclose(rarquivo5);
		}
	}
	
	else if(g > 4 || g < 0)
	{
		printf("-- ENTRADA INV�LIDA, INSIRA UMA OPC�O DO MENU --\n\n");
	}
	
	else
	{
		return 0;
	}
	
	}
	
	free(com);
	free(drinks);
	free(selfcare);
	free(cleaning);
	free(cigarrete);
}


